#! /usr/bin/env my-dart

import 'dart:core';
import 'package:sys/sys.dart' as sys_sys;
import 'package:args/args.dart' as args_args;

main(List<String> args) async {
  var parser = args_args.ArgParser();
  parser.addCommand('cutDemo');
  var results = parser.parse(args);
  var commandResults = results.command;
  if (commandResults == null) {
    throw 'Valid command not specified';
  }
  switch (commandResults.name) {
    case 'cutDemo':
      {
        await cutDemo(commandResults);
      }
  }
}

Future<void> cutDemo(args_args.ArgResults commandResults) async {
  if (commandResults.rest.length != 2) {
    throw 'File name count is ${commandResults.rest.length}: ${commandResults.rest}';
  }
  String filePath = commandResults.rest[0];
  filePath = sys_sys.pathFullName(filePath);
  String outPath = commandResults.rest[1];
  outPath = sys_sys.pathFullName(outPath);
  String text = '';
  List<String> lines = sys_sys.readFileLines(filePath);
  for (int i = 0; i < lines.length; i++) {
    String line = lines[i];
    if (line.startsWith('block.launch(')) {
      break;
    }
    text += '$line\n';
  }
  sys_sys.writeFileString(outPath, text);
}
